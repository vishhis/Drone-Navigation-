=======================
Open Source Licence
=======================

DroneKit-Python is licensed under the *Apache License Version 2.0, January 2004* (http://www.apache.org/licenses/). This is present in the `LICENSE <https://github.com/dronekit/dronekit-python/blob/master/LICENSE>`_ file in the source tree, and reproduced below:

.. include:: ../../LICENSE
    :literal: